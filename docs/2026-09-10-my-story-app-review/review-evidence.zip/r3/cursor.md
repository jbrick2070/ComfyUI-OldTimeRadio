VERDICT: yes-with-fixes -- workstream order is right, but several named seams would mis-bind (player path/codec, widget-32 vs gate_in slot 32, `_literal` vs INT widgets, draft-vs-roll timing) if coded from this text as-is.

MUST-FIX BEFORE BUILD:
1. [§7 D4] Player source is the wrong file if implementers follow "observed terminal path" / `final_video_path`. `OTRMasterAudioMux.mux` archival `final` is PCM; the OBS copy is AAC (`tests/test_video_render_path_cw4.py` ~391-399). Browser App playback must use the publishable OBS path (`obs_copy` / `meta.obs_final_path`) after a successful publish; keep `result[0]` as archival `final`. Withheld publication must not put the archival PCM file in `ui.gifs` and call it published.

2. [§6 D3 + canonical] "Append after widget 32 (`replay_from`)" collides with link identity. `widgets_values[32]` is `replay_from` (`workflows/otr_canonical.json` ~541; 33 slots, last `""`). `inputs[]` index 32 is `gate_in`; link 279 is `[279, 63, 0, 1, 32, "STRING"]` (~3402-3407). Append the three new fields after `replay_from` in `INPUT_TYPES` optional (and at the end of `inputs[]`/`widgets_values`). Do not insert before `gate_in`. Do not retarget dst_slot 32. Inserting before `gate_in` silently breaks validator->writer ordering.

3. [§5 D2 admission] Do not reuse `_otr_visual_assets._literal` (`nodes/_otr_visual_assets.py:58-64`) for My Story fields. It treats every non-`str` as linked and raises `VisualAssetError`. Canonical `num_characters` is INT (`widgets_values[1]` is `2`). Reuse the existing gate walk in `plan_prompt` (`:238-264`) only. Separate readers: STRING vs INT vs COMBO; `[src_id, slot]` list = defer; missing new keys on old prompts = empty, not a link. Empty/`None` `prompt` is the existing "live queued prompt required" failure, not a blank-idea reject. Raise an admission error, not `VisualAssetError`.

4. [§5 D2 sequencing] Split two writer moments that the text currently mashes together. Current `run()`: replay (`OTR_LedgerScriptWriter.py:2906-2921`) -> rolls (`:2951-2956`) -> `_source_bank_row` (`:2957`) -> LLM preflight (`:2987`) -> later `_resolve_inputs`. Required order: (a) replay unchanged; (b) persist draft from requested pre-roll widgets (sentinel bank/style included); (c) rolls; (d) bind row; (e) evaluated admission; (f) preflight/env/`_resolve_inputs`. Saving the draft after rolls makes validator vs writer digests diverge (`source_bank` queued `"roll (any eligible bank)"` vs resolved id). Validator save stays before both `ensure_prompt_visual_assets` calls (`_otr_workflow_validator.py:500-501` and `:569-570`).

5. [§4/§5] `_resolve_inputs` currently does `num_characters = max(1, min(_FABLE2_MAX_CAST, int(num_characters)))` with `_FABLE2_MAX_CAST = 10` (`_otr_writer_inputs.py:62,242`). That overwrites the request. My Story must keep requested vs actual separate; clamp/stock limits belong in the runner/cast result, not this assignment.

6. [§5] Policy keys cannot be unknown top-level bank keys (`_BANK_KEYS` `_otr_story_routing.py:217-221`; `_check_unknown_keys` `:205-209`). Put `story_input_mode` / `auto_select` in `defaults` (already scalar). Add `_parse_bank` enum + mutex validation there (`user_fields_v1` + `auto_select=true` rejected). Same `_parse_bank` is injected into client discovery (`:576`). Absent keys: `legacy` / `true`. Do not special-case bank id `my_story` in `_otr_rolls.eligible_bank_ids` (`:180-196`); change the predicate to `runnable and effective_auto_select`.

7. [§5] `default_story_pipeline` must be a new `LANE_SPECS` id, never `original_multi_pass`. `runner_for` returns `None` for inline (`_otr_lane_specs.py:83-87,113-123`) and the writer falls through to the original body (`OTR_LedgerScriptWriter.py:3432-3473` vs `:3475+`). Empty fetcher+interpreter still hits `_bank_has_no_source_contract` (`_otr_writer_inputs.py:325-354`) unless the `user_fields_v1` branch runs first. Pack `story_pipeline_id` must equal the bank pipeline (`_otr_story_routing.py:483-487`). Custom seams need exact three-way parity pack / `declared_seams` / pass `seam_refs` (`:504-513`). Do not copy `original_multi_pass` seams (`pipelines.json:96-99`).

8. [§5] Draft root `otr/story_drafts/...` is not an output-root path. Episodes follow `comfy_output_dir()` which prefers `OTR_OUTPUT_DIR` over `folder_paths.get_output_directory()` (`_otr_paths.py:122-140`). Resolve drafts as `comfy_output_dir()/otr/story_drafts/<digest>/input.json`. D4 player paths stay on `folder_paths.get_output_directory()` (served root). Those two roots are allowed to differ.

9. [§5/§6] Same change as the three widgets: `python scripts/build_variants.py --all` then `--check`. Widget-vector gate (`_otr_workflow_validator.py:547-558`) plus `tests/test_source_bank_widget_2c.py` (`len == 33`) will fail if variants/tests lag. `test_widget_value_alignment.py`, `test_canonical_widget_input_parity.py`, `test_workflow_link_target_indexes.py` as named in repo rules.

SHOULD-FIX:
1. [§6 vs §5] App form omits `replay_from`. Replay is still the first statement of `run()` and ignores live fields. Canonical default is blank (`widgets_values[32] == ""`), but a graph-mode leftover would make App Mode look like My Story while replaying. Surface `replay_from` or fail My Story when it is nonblank with an explicit message.

2. [§7] Do not copy `video_engine.py:2352-2358` (`"/output/"` split) for `ui.gifs.subfolder`. Relativize against `folder_paths.get_output_directory()`. Emit `{filename, subfolder, type:"output"}` only when the file is inside that served root.

3. [§5 snapshot] `load_snapshot_for_bank` strict-misses when `OTR_SOURCE_SNAPSHOT_MANIFEST` is set and the base is absent (`_otr_source_snapshot.py:175-189`). A new runnable `my_story` breaks any strict manifest until an entry exists or `allow_partial` is true. Keep existing banks unchanged; document the soak/env implication before flipping `runnable`.

4. [§4/§5 cameo] `test_every_shipped_bank_has_a_DECIDED_cameo_policy` will fail until `BANK_CAMEO_POLICY` gains `my_story` (`tests/test_cast_lock_policy_repin.py:435-460`). Updating the map is not the user-cast vs house-cameo behavior. `_source_bank_excludes_lemmy` only excludes `public_domain`/`shakespeare` (`_otr_casting.py:1178-1189`). D1 must name a lock_cast-visible receipt; "cameo_allowed" plus a user "only these people" note will still admit Lemmy on `always include`.

5. [§4 `include_act_breaks`] Widget remains live (`widgets_values[5] == true`, not in the App list). It still flows through `_resolve_inputs` into the tail (`_otr_writer_tail.py:865`, `_otr_episode_budget.py:254`). D1 must say whether the dispatched runner honors it; default-true is not "hidden/off".

6. [§5 `_resolve_inputs` signature] New fields must be keyword-only with `""` defaults after the existing `*` (`_otr_writer_inputs.py:123-199`). Forward `run -> _resolve_inputs -> resolved["source_meta"]`; never an 8th `SOURCE_PAYLOAD_KEYS` member (`_otr_source_payload.py:129-130`).

7. [§5/§7] D1 must pin `outline_view.premise` / `.title` (and the other `WriterTailContext` attrs at `_otr_writer_tail.py:602-619`). Duck-type the tail parts; do not import `NewsProOutlineView` / scifi tail class.

OPTIONAL / NICE-TO-HAVE:
- `ui.files` sidecar report; player + honest withheld status are the delivery contract.
- App-setup probe that `OTR_OUTPUT_DIR` == served output root (already a stated limitation).
- Treat whitespace-only the same as blank at both validator and writer with one strip rule in `_otr_story_input` (D1 digest).

CUT THESE:
1. Top-level bank keys for policy -- `_BANK_KEYS` reject them; `defaults` already takes scalars. Safe: existing/client rows stay valid with absent keys.
2. Copying `original_multi_pass` `declared_seams` / spark path -- forces original prompt IDs through three-way parity and reopens `_bank_has_no_source_contract`. Safe: dispatched lane + `user_fields_v1` branch is the specified alternative.
3. Restoring `LaneSpec.compat_attr` / `story_rules` / 8th payload key -- already deleted; tests pin the absence (`nodes/_otr_lane_specs.py:68-70`).
4. Building `WriterTailContext` inside the new runner -- writer already does that at `:3448-3473`. Safe: return duck-typed parts only.
5. Reindexing link 279 "to be safe" after trailing widget append -- gate_in stays dst_slot 32. Reindex is how this graph gets corrupted.

[ASSUMPTION] Installed frontend 1.49.6 `extra.linearData` / `ui.gifs`+`ui.files` on one OUTPUT_NODE -- not in this repo; prove on the live frontend before advertising the player (§2/§7).
[ASSUMPTION] Production soaks do not currently export `OTR_SOURCE_SNAPSHOT_MANIFEST`; if they do, item 3 is a launch blocker.
UNTRACED -- could not follow App Builder writeback of `label` vs `localized_name` in this tree; verify against the 1.49.6 frontend before renaming in canonical JSON.
