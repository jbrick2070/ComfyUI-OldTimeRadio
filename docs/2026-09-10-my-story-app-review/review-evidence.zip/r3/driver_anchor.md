VERDICT: yes-with-fixes as scope; no build until independent D1 artifacts exist.

Written before R3 fanout. Both reviewers receive exact R2 final bytes. Codex
remains grounded panelist and sole judge, with no duplicate Codex CLI seat.

USER-CONFIRMED BOUNDARIES
Optional idea/character-notes/plot/setting fields; keep existing act_count and
num_characters visible. LLM interprets and fills gaps into full ledger.
Successful My Story means a real published episode. Save input drafts on Run;
a report/archive is not a substitute deliverable.

WIRING MUSTS
1. Append three optional strings after replay_from32, preserve earlier widget
   indices/graph identity/links; forward every field through resolver/sidecars
   and runner. App order is separate from serialized widget order.
2. Validator63 -> writer1 gate279 currently precedes asset downloads. Admit and
   save canonical literal input there before downloads, and evaluated linked
   input before writer generation. No double rolls; retain raw controls before
   resolution and exact draft identity at both boundaries. Frozen-episode and
   source-snapshot replay have distinct authority; snapshots need versioned fields.
3. Publication-required intent must reach terminal85 through owned metadata,
   compatible with existing banks; freeze remains sole eligibility writer.
   Never force a rights result; fail unexpected My Story withheld delivery.
4. Native terminal media/report need real served files and same episode/job.
   External OBS still publishes with truthful inline-preview limitation;
   external episode root has an explicit native-preview setup limitation.

KEEP BOUNDED
Drafts are durable input artifacts under otr/story_drafts, never rendered media.
No wizard/autosave UI, endpoint, viewer conversion, alternate graph or deployment
change. D1 still owes exact schemas/pass graph/cast/cameo/draft/delivery contracts.
R3 makes dependencies concrete; it cannot claim preflight or live proof passed.
