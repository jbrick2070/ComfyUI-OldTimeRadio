# User clarification during R1

The user clarified: an LLM needs to extrapolate from user input into a complete
script ledger. Interpret this as accepting rough free-form TEXT: a phrase,
sentence, plot fragment, character notes, or a messy paragraph. The LLM owns
interpretation, invention of missing detail, and full script authorship. The
user does not supply ledger JSON, a fully specified brief, or a finished script.

Preserve clear user intent and named details while permitting creative
elaboration. Do not turn every input token into an immutable literal or require
a mandatory clarification interview. This does not expand the scope to audio,
image, file-upload, transcription, or verbatim-script import.

R1 CLI calls were already running against their immutable original input.
The driver will incorporate this clarification when synthesizing R1 final.md,
which becomes the exact input to R2. No in-flight reviewer input is rewritten.
# R2 steering: optional fields and retained counts

User clarified while R2 CLI reviews were in flight: typing an original story
should have good UI fields for character names/ideas, plot ideas and setting.
Act count remains the length control, and character count remains available.

Incorporate after the immutable R2 input reviews, before R3: expose both
existing act_count and num_characters; retain a general idea field; scope
optional character notes, plot and setting fields. The LLM combines supplied
fields and fills gaps. This is not a mandatory form or user-authored ledger.
New optional widgets must append at the end, be wired into the canonical in
the same future code change, and be bank-local in effect. Character count is
an explicit request to reconcile with names, not a hidden two-person default.
# R2 steering: published episode is required; save input drafts

User corrected the discussion of fallback status: My Story must always produce
a published episode on success. A report or archival-only result is not an
alternate successful deliverable. Preserve input drafts separately for editing
and retrying. Incorporate this in R2 synthesis, then R3/R4.

Scope saved input on Run, before generation, rather than an autosave-on-every-key
frontend or a draft-approval wizard. Save exact fields and controls durably,
associate the resulting episode with its source draft, and preserve drafts on
failure/cancellation. My Story's unexpected publication refusal is a failed
delivery, never a successful no-video report. Existing other-bank publication
behavior is separate and remains compatible.
# R3 steering: App UI included, App view optional

User asks to ensure App UI features are scoped and clarifies that many people
will not enable the App sidebar/view. All fields and complete generation,
draft preservation and published delivery must work in normal graph view too.
App Mode is an optional easier presentation of the same canonical controls;
graph stays the default. Include both-view acceptance; no App-only backend path.
LATEST: GO_FORWARD priority #1 integration
Add both My Story and the supplied Opus cleanup plans to GO_FORWARD so the next
person starts there, in logical sprint order. Use 1-2 helpers for ideas. Retain
the speaker-placement preference as optional follow-on: balanced gentle
positions per stable speaker identity per episode, centered narration, all
supported cast sizes, stable across lines. Cleanup itself was already reviewed
and its preparation pushed as a3551ff5; runtime changes remain pending for Opus.
FINAL OWNERSHIP CLARIFICATION DURING R4
The user accepted the proposed split and asked to make it explicit in
GO_FORWARD and supply a Codex starter prompt: Opus owns cleanup sprints 1-2;
Codex owns My Story sprints 3-5, after the cleanup's qualified pushes. Another
reviewer checks finished code changes. This does not request a new task or
runtime implementation in the current scoping turn. GO_FORWARD's reviewed
snapshot predates this small owner clarification; final receipt distinguishes it.
PROMPT CORRECTION
The user immediately corrected the requested starter prompt to OPUS, not
Codex. Keep the accepted coding-owner split in GO_FORWARD. Deliver the prompt
for Opus to begin cleanup P1/P2/P3, then hand off to Codex for My Story.
FINAL SCOPE CUT DURING R4 JUDGMENT
The operator explicitly said backward compatibility with old recorded replays
is not worth chasing. Remove the reviewer's proposed legacy intent synthesis
and migration/old-bundle acceptance requirements. Preserve current-contract
replay and new-run behavior for existing banks; old incompatible replay bundles
may fail clearly. Record this explicit cut in GO_FORWARD and the final scope.
FINAL CLARIFICATION: NO REPLAY WORKSTREAM
The operator clarified they never designed/requested a replay system. The
driver removed My Story saved-episode rerendering, source-snapshot restoration,
legacy migration, related App controls and qualification. Keep saved input
reuse/fresh generation only. Existing bypass settings get a cheap clear
incompatibility rejection so they cannot silently replace submitted input.
No current-contract replay feature is required either. Real canonical workflow
is the sole run source; old harness graphs are not an acceptance target.
