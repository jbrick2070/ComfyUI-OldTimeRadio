VERDICT: yes-with-fixes as integration scope; independent bank design remains D1.

Written before either R2 CLI invocation. Codex is driver and sole judge.
Input is exact R1 final.md. User now explicitly wants rough input interpreted
by an LLM into a full script ledger, without a form or user-authored schema.

MUST-FIX / VERIFY IN CODING PLAN
1. Shared admission contract needs concrete ownership without creating a
   source-routing cycle. Current _otr_rolls imports routing; validator and
   evaluated writer must consume policy without resolving/drawing twice.
   Canonical admission is queued literals before both visual-asset paths;
   replay and linked-input caveats are explicit. Preserve existing banks.
2. Require the independent design to assign raw input, interpretation,
   explicit requirements, authored fields, closure, repair and final TTS/hash
   owners. This review cannot manufacture a bank design by copying originals.
3. Terminal media wrapper needs direct-call migration as well as Comfy wire
   compatibility. Use proven server-root containment and truthful external-root
   fallback; publication status and native preview availability are different.

SHOULD-FIX
Keep docs currentization first and bounded; same-widget labels/actual bank IDs
are UI truth. Keep explicit character requirements above hidden num_characters,
but do not force every incidental named entity into the cast. Context capacity
is not a word-count quality gate.

CUT
No executable change, render, package publish, new media derivative/endpoint,
custom wizard, alternate graph, model swap, or retrospective Gate1 PASS here.
Known root paths/frontend version were read on Windows; live UI proof pending.
