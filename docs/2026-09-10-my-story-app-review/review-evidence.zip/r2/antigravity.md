﻿VERDICT: yes-with-fixes

The scope document correctly identifies key operational constraints: act-based sizing (acts 1-6) rather than obsolete word targets, canonical graph retention without a frontend fork, and handoff to the shared writer tail. However, the coding plan contains several severe implementability flaws, API breakages, and data flow traps that will break existing tests and fail execution if coded as written.

================================================================================
MUST-FIX BEFORE BUILD
================================================================================

1. [D3] DO NOT RENAME PROGRAMMATIC SOCKET/WIDGET NAMES ON NODE 1
   - Issue: Section 6 proposes renaming node-1 inputs/widgets directly (e.g., custom_premise to "Story input", visual_style to "Look").
   - Reality: In ComfyUI graph execution (and specifically `scripts/otr_api.py:573`), node inputs and widget values are mapped by their exact programmatic socket names. Furthermore, `tests/test_canonical_widget_input_parity.py:103-128` explicitly asserts parity between widget names, indices, and inputs. Renaming `name` in `workflows/otr_canonical.json` breaks execution and fails the test suite.
   - Fix: Keep internal socket/widget names intact (`custom_premise`, `act_count`, `visual_style`, `source_bank`). Apply user-facing labels strictly through App Mode metadata (`extra.linearData.inputs` using `[node_id, widget_name, {label: "Story input"}]` or `localized_name`), leaving graph socket names unaltered.

2. [D2] ELIMINATE THE EMPTY-FETCHER HIJACK IN `_otr_writer_inputs.py`
   - Issue: Section 2 notes that an empty fetcher/interpreter selects original-bank initialization, but Section 5 does not define the concrete code change in `nodes/_otr_writer_inputs.py`.
   - Reality: `_bank_has_no_source_contract(bank)` at `nodes/_otr_writer_inputs.py:536-540` checks `bank.runnable and not bank.fetcher and not bank.interpreter`. If `my_story` is added as runnable without a fetcher, `_resolve_inputs()` routes it into `_OTROR.draw_spark_atoms()`, drawing random spark atoms and demoting `custom_premise` to an `operator_hint`!
   - Fix: Explicitly restrict `_bank_has_no_source_contract` to `bank.source_bank_id == "original"` (or require an explicit empty-contract flag), and add a dedicated ingress branch in `_resolve_inputs` for `my_story` that accepts raw prompt text and forwards it directly to resolved inputs.

3. [D1/D2] SPECIFY RUNNER RETURN CONTRACT; DO NOT DEFER `WriterTailContext` REQUIREMENTS
   - Issue: Section 4 defers the bank design, while Section 5 lists `nodes/_otr_my_story.py` and registers it in `_otr_lane_specs.py`.
   - Reality: In `nodes/OTR_LedgerScriptWriter.py:3448-3470`, dispatched runners are invoked as `runner(ctx)` and must return an object providing `.outline_view`, `.canon`, `.final_title_override`, and `.run_story_spine`. If these attributes are missing or named differently, assembly of `WriterTailContext` crashes at line 3470 before downstream ledger production or freeze can occur.
   - Fix: Define the concrete return schema (`MyStoryTailParts`) in the coding plan before implementing `nodes/_otr_my_story.py`, ensuring it satisfies `WriterTailContext` requirements.

4. [D4] MIGRATE TUPLE UNPACKERS ACROSS ALL 4 ACTIVE TEST CALLERS OF `OTR_MasterAudioMux.mux`
   - Issue: Section 7 states that `OTR_MasterAudioMux.mux` will return `{"ui": ..., "result": (final_video_path, report_path)}` to support ComfyUI media results, but does not identify the exact callers that will break.
   - Reality: In Python, returning a dictionary breaks tuple unpacking (`video, report = mux(...)`), causing `video` to become `"ui"` and `report` to become `"result"`. Four active callers unpack the return value as a 2-tuple:
     - `tests/test_publication_eligibility.py`: lines 582, 621, 679
     - `tests/test_video_render_path_cw4.py`: line 375
     (Line 142 in `test_video_render_path_cw4.py` tests an exception raise and remains unaffected).
   - Fix: Update all four test callers to unpack `res["result"]` (or handle dict returns) when invoking `mux()` directly.

5. [D4] PROVIDE A NATIVE FALLBACK MEDIA ENVELOPE WHEN OBS IS EXTERNAL (`ui.text` IS IGNORED)
   - Issue: Section 7 proposes showing a truthful path/report with preview-unavailable status for external/unservable OBS paths, but suggests using `ui.text`.
   - Reality: In installed ComfyUI frontend 1.49.6 (`resultItemParsing.ts`), `ui.text` is not parsed into App Mode output items. Only `ui.files`, `ui.images`, `ui.gifs`, and `ui.audio` produce visible outputs. Returning `ui: {"text": [...]}` results in a blank output pane in App Mode.
   - Fix: When `OTR_OBS_DIR` is outside `folder_paths.get_output_directory()` or publication is withheld, write a status report file under ComfyUI's served output directory (`reports/episode_status.txt`) and return it via `ui.files` matching the core `SaveText` pattern (`comfy_extras/nodes_text.py:64-72`), omitting `gifs`.

6. [D2] REPLAY INGRESS MUST BYPASS THE WORKFLOW VALIDATOR'S BLANK-PREMISE CHECK
   - Issue: Section 5 specifies validating literal `custom_premise` in `_otr_workflow_validator.py` before `ensure_prompt_visual_assets` (link 279).
   - Reality: In replay runs (`replay_from` populated or `OTR_SOURCE_SNAPSHOT_MANIFEST` active), live premise widgets can legitimately be blank because creative authority resides in the frozen replay snapshot. If the validator unconditionally requires non-blank `custom_premise` when `source_bank == "my_story"`, all valid replays of My Story will fail early.
   - Fix: The admission helper must inspect `inputs.get("replay_from")` and snapshot existence first. If replay authority is active, bypass the live premise check.

7. [D2] EVALUATED WRITER PREMISE CHECK MUST PRECEDE SLOT PREFLIGHT AND SCAFFOLD MUTATION
   - Issue: In `OTR_LedgerScriptWriter.py`, slot preflight occurs at line 2987 and `_apply_story_scaffold_env` at line 2997.
   - Reality: If evaluated premise validation runs during or after `_resolve_inputs` (line 3059), the writer has already preflighted LLM slots and mutated environment variables.
   - Fix: Place the evaluated premise check at line 2958 (immediately following bank admission at line 2957), prior to `_preflight_llm_selection` and `_apply_story_scaffold_env`.

8. [D2] `banks.json` REGISTRY ENFORCES A CLOSED TOP-LEVEL KEY SET
   - Issue: Section 5 suggests declaring input and roll policies in `nodes/story_packs/banks.json`.
   - Reality: `_BANK_KEYS` in `nodes/_otr_story_routing.py:218` strictly validates top-level bank keys against a closed set. Adding new top-level keys (e.g. `roll_policy`, `input_policy`) causes `_parse_bank` to fail on startup.
   - Fix: Store bank policy flags inside the existing scalar `defaults` dict (which allows scalar values) or resolve selection rules within `nodes/_otr_rolls.py`.

================================================================================
SHOULD-FIX
================================================================================

1. [Multi-field Ingress] APPEND NEW OPTIONAL WIDGETS AFTER `replay_from` AND USE SIDECARS
   - `OTR_LedgerScriptWriter.INPUT_TYPES` ends optional widgets with `replay_from` at index 32 (line 2751). If optional fields (character notes, plot, setting) are added, they must be appended after `replay_from` to avoid altering the positional indices of existing saved widgets.
   - In `_otr_source_payload.py:157`, the payload schema strictly allows seven string keys. Do not expand this envelope; store multi-field bundles in versioned `source_meta` sidecars and snapshots.

2. [Character Count] `num_characters` IS SPEAKING COUNT PLUS ANNOUNCER, NOT A HARD CEILING
   - `OTR_LedgerScriptWriter.py:2062` documents `num_characters` as requested speaking cast plus announcer. When a user provides explicit character names/notes, the runner must prioritize user-defined cast requirements over the default `num_characters=2` without throwing arbitrary size validation errors or truncating characters.

3. [Title Hierarchy] RESPECT EXPLICIT `episode_title` PRECEDENCE IN SHARED TAIL
   - In `nodes/_otr_writer_tail.py:731-741`, an explicit `episode_title` widget input overrides the runner's accepted title. While canonical `episode_title` is currently blank, the plan must document this hierarchy accurately rather than asserting that the runner-generated title unconditionally wins.

4. [Post-Runner Boundaries] VERIFY FINAL TEXT AND HASHES AFTER RECONCILIATION AND FREEZE
   - Dispatched runner output passes through `_otr_writer_tail.py:1377-1405` for creative clean, technical cleanup, and reconciliation before reaching the readonly freeze. Test assertions must verify post-reconciliation text, TTS projections, and publication eligibility receipts, not just raw runner artifacts.

================================================================================
OPTIONAL / NICE-TO-HAVE
================================================================================

1. NATIVE COARSE NODE STATUS VIA EXECUTION MESSAGE
   - ComfyUI supports updating execution messages via node properties. Emitting coarse stage messages (e.g. "Interpreting story premise...", "Generating script ledger...") on Node 1 provides helpful feedback in App Mode without requiring custom frontend JavaScript.

2. `LinearPreview` DOWNLOAD / HISTORY PARITY TEST
   - Add an automated test verifying that the terminal mux return (`ui.files` or `ui.gifs`) populates `useOutputHistory` in `comfyui_frontend_package-1.49.6` cleanly, ensuring download buttons function as expected.

================================================================================
CUT THESE (over-engineering)
================================================================================

1. CUT BESPOKE FRONTEND COMPONENTS, COMBO ALIAS EXTENSIONS, AND DRAFT WIZARDS
   - App Mode 1.49.6 is strictly a native form wrapper over graph widgets. Any attempt to build wizard flows, custom thumbnail pickers, or frontend extensions is out of scope and unmaintainable.

2. CUT NEW MODEL ROUTES, DIRECT PROVIDER APIS, AND CREDENTIAL MANAGERS
   - Stay strictly within the two existing configured LLM slots: the creative slot for drafting and repair, and the technical slot for extraction and structured validation.

3. CUT WORD-COUNT QUALITY GATES AND COMPATIBILITY BRIDGES
   - Do not reintroduce `target_words`, word-count ladders, or `LaneSpec.compat_attr`. Story sizing is governed exclusively by `act_count` (1-6).

4. CUT LOCAL MEDIA CONVERTERS OR STREAMING ENDPOINTS FOR EXTERNAL OBS
   - When OBS output is configured outside the ComfyUI served output directory, report preview unavailability honestly via a status text file. Do not build file-copying shims or spin up local web servers to bypass this limitation.
