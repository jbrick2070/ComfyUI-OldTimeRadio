# R2 driver grounding and mid-round steering

Real Windows reads only. Internal grounding helpers are not CLI panel seats.
The R2 input and driver_anchor remain unchanged while the two reviews run.

User steering now explicitly calls for optional character names/notes, plot
and setting fields beside the general idea, with both act count and character
count retained. Apply in R2 synthesis and subject to R3/R4; it supersedes the
single-field/hidden-cast-count assumption in the reviewed R2 input.

## Multi-field ingress

- Writer INPUT_TYPES currently ends optional widgets with replay_from (:2751).
  Canonical indices are num_characters1, custom_premise4, act_count6,
  replay_from32. gate_in is forceInput, no saved widget slot. Append new optional
  values after replay; arrange their App visual order separately.
- _otr_writer_inputs:266 strips custom_premise; no raw separate input survives.
  _otr_source_payload:157 permits exactly seven string keys. Raw field bundle
  belongs in versioned source_meta/resolved sidecars, not additional payload keys.
- Explicit forwarding is required through run -> _resolve_inputs -> resolved
  -> dispatched runner and final ledger receipts. New widgets alone are inert.
- Writer:2062 documents num_characters as requested speaking count plus
  announcer, not hard cap. Input normalization at239 does not define new-bank
  cast meaning. Resolve explicit names/counts without losing user instructions.

## Two replay contracts

- writer replay_from fast path:2906 ignores all live authoring values.
- _resolve_inputs:288-305 loads OTR_SOURCE_SNAPSHOT_MANIFEST before live branches;
  a matched snapshot replaces source payload/sidecars. _otr_source_snapshot:175
  rejects missing bank in strict manifests unless allow_partial is explicit.
- A new user-fields snapshot must preserve the exact field bundle. Define
  mismatch behavior instead of silently combining stale source and current UI.
  Cheap admission must consider legitimate snapshot authority; do not call all
  blank live fields an error when a validated frozen source supplies them.

## Shared writer boundaries

- writer:3228-3383 seeds/saves ledger source/style/provenance before dispatch.
  Dispatch:3434 precedes inline legacy style/cast; tail context sets contract=None,
  style_grammar_on=False. New runner owns authoring, not all downstream behavior.
- _otr_writer_tail:731-741 gives explicit episode_title widget priority over the
  accepted runner title. Canonical title is blank. Record graph override and
  final title honestly; do not falsely promise the runner title always wins.
- Tail:1377-1405 still runs creative clean, technical cleanup, reconciliation.
  Final delivered text/TTS/hash/provenance needs acceptance, not only first draft.

## Native output/status contract

- Installed core execution.py:343-374 independently extracts ui/result from dict.
- Installed frontend resultItemParsing.ts ignores ui.text but accepts real
  ui.files descriptors. Core SaveText (comfy_extras/nodes_text.py:64-72) shows
  real .txt plus filename/subfolder/type output metadata. App recognizes .txt.
- A real episode report can provide a native withheld/external-OBS status when
  episode storage is in the served output root. A bare STRING socket/ui.text
  cannot promise App visibility. Inline content does not make downloads valid.
- OTR_OUTPUT_DIR outside server output remains an unsupported native-preview
  configuration. Setup must expose that limitation; preserve existing valid
  headless output behavior and never invent a reachable descriptor.
- linearOutputStore follows new job by default; deliberate history selection
  remains selected. No-media completion removes pending items, not prior history.
  Error/cancel state exists; prove current versus historical job association.
- LinearPreview supports Download/Download All; useOutputHistory filters output
  node IDs. Real custom mux media/report save/reload/play/download remains a
  browser proof obligation.
- Execution Message node property gives native coarse node status; no proof of
  detailed progress inside writer passes. Optional wording, no custom frontend.

## Direct mux callers

Five active direct calls: test_publication_eligibility:582,621,679 and
test_video_render_path_cw4:142,375. Four successful tuple unpackers need update;
the raising call at142 must retain failure. Separate .claude worktree duplicates
are not active checkout callers. Canonical audio checker does not call mux.

## Registry policy surfaces

SourceBank.defaults is scalar-valued, stricter opt-in semantics are validated
in _otr_story_routing._parse_bank. Unknown top-level keys fail. Missing new
policy defaults must preserve existing shipped/client rows; rejected client
metadata follows existing quarantine behavior. _otr_rolls imports routing;
keep the input helper free of model/runner imports and avoid reverse imports.
