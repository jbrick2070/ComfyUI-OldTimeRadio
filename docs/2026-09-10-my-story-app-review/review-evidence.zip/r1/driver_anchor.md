VERDICT: yes-with-fixes as a scoped work package; no as an executable bank design.

MUST-FIX BEFORE BUILD
1. [D1/D2, CONFIRMED] Preserve the distinction between a hardened scope and a
   locked independent bank design. The live guide forbids a renamed existing
   bank and requires concrete schemas/ownership before implementation. This
   campaign must not silently waive that boundary or claim it already passed.
2. [D2/D3, CONFIRMED] A required-premise bank is incompatible with the current
   all-runnable roll pool unless an explicit input/selection policy lands.
   _otr_rolls.eligible_bank_ids currently filters only runnable; keep blank
   dailies and existing eligibility intact. Make this a release-blocking
   integration requirement, not a later enhancement.
3. [D2, CONFIRMED] Early blank-input validation needs an exact ordering boundary:
   the writer's replay fast path precedes rolls, bank gating, LLM preflight,
   environment changes and _resolve_inputs (writer lines 2897-3064). Keep
   replay independent of live premise widgets; do not validate blank text
   before replay or only after expensive downstream work.

SHOULD-FIX
1. [D0, CONFIRMED] Bound the documentation refresh to a named file/section
   inventory. The linked-operational-guidance clause can expand indefinitely;
   dated bug narratives stay historical and code behavior is not changed to
   satisfy stale prose.
2. [D3, CONFIRMED] The four-field native form still requires selecting My Story;
   it does not provide separate app-mode defaults or a custom Create button.
   Frame user acceptance around that actual interaction, not a standalone app.
3. [D1, UNVERIFIABLE until design] The scope declares semantic premise retention
   but lacks a resolved contradiction/overlong-input policy. Require a bounded
   handling contract; do not manufacture an objective semantic guarantee from
   hashes, phrase matching, or a model's own review opinion.

OPTIONAL / NICE-TO-HAVE
Native player and existing style dropdown are enough for the first slice.
No website, import UI, new hardware profile or new model selection is needed.

CUT THESE
Do not let this scope review reopen accepted script quality or old word-fit
policies. The operator's later directives in CLAUDE.md supersede the guide's
old wording. Full docs corrections and implementation remain future work.

Grounding: real Windows files, canonical hash unchanged since the saved scope.
No implementation, tests, headless boot, or live render performed.
