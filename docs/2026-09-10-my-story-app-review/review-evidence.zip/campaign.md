# My Story scope: full Kibitz R1-R4

User request: review the scope through R1, R2, R3 and R4. Preserve the earlier
documentation-only limit. This campaign may revise the scope; it does not
implement the bank or currentize the linked guides themselves.

Driver: Codex, author of each grounded anchor and sole judge/synthesizer.
Panel: Antigravity (Gemini 3.8 Flash (High)) and Claude Code (sonnet alias,
high effort). Two independent CLI reviewers per round follows the repo's
one-or-two-lane rule. No duplicate Codex CLI reviewer. Expected calls: 8;
record actual attempts and successful reviews at completion.

R1 substitution: Claude Code returned rc=1 with "OAuth session expired and
could not be refreshed" before providing a review. Its failure artifacts are
retained. Cursor (cursor-grok-4.6-high, catalog-checked current) fills that seat
for R1 and later rounds. This is authentication failure, not quota exhaustion.
Expected final successful reviews remain eight; the failed Claude attempt is
counted separately. No operator login task blocks this campaign.

R2-R4 runner scheduling: invoke the standard runner once per independent seat
concurrently, using topics my-story-app (Gemini) and my-story-app-cursor
(Cursor). Separate topic directories prevent runner input/output races. Both
receive the exact prior master final.md and a byte-identical driver anchor
written before launch. Copy Cursor review/selection/status receipts into the
master round after completion; retain original locations in the campaign
receipt. This is one review per seat per round, not duplicate panel calls.

Runner: C:/Users/jeffr/.codex/skills/kibitz/scripts/kibitz.py.
Input: docs/2026-09-10-my-story-app-scope.md at b9d7be08.
Each later round consumes the exact previous final.md bytes.

Pin checks: stock Gemini 3.7 pin was reported a generation behind. Refreshed
the campaign environment to the catalog-confirmed Gemini 3.8 Flash (High);
second pin check reports current. Claude uses the skill's sonnet/high alias.

Profile handling: read the generic ComfyUI profile and existing local overlay.
The September 4 overlay is 1,705 lines and contains stale frontend facts and
paths under an unrelated .claude worktree. Use --no-profiles for this scoped
documentation campaign; the reviewed plan already states the real canonical,
Windows paths, node/widget/output and no-render constraints. Anchors and
grounding explicitly apply those constraints. Do not infer facts from the
stale overlay or update it as part of this scope review.

Grounding helpers: two internal read-only agents, not external panel seats.
Reviewers may write only their review artifacts. No code, workflow, tests,
source-bank registries, production logs, or existing operational guides may
be edited during this campaign, except GO_FORWARD_PLAN.md under the later
explicit operator request below. Existing unrelated dirty files are preserved.

The bank design-independence preflight is distinct from this review campaign.
Do not turn R4 completion into a claim that the bank has been implemented,
live-qualified, or independently designed before the earlier exploratory reads.

Late operator scope expansion before R4: add this plan AND the already reviewed
Opus cleanup handoff/plan to GO_FORWARD as priority #1, with logical sprints and
1-2 helpers for ideas. The driver updated all three GO_FORWARD entry points;
two existing read-only helpers verified the sequence and retained requirements.
R4 input/anchor include the combined handoff and optional speaker-placement
follow-on. Earlier rounds of this campaign are not claimed to have reviewed
cleanup; its independent 14-call campaign remains separately owned/referenced.
