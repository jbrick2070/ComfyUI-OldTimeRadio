# Round 4 Review: My Story + Native App Mode Implementation & Documentation Scope

## VERDICT
yes-with-fixes -- The plan is architecturally converged, schema migrations and slot math are rigorously grounded, and frontend binding contracts are verified; however, three build-blocking defects remain: an unguarded `comfy_execution` import breaking unit test suites, an atomic desynchronization between Chunk 3 and Chunk 4 for `OTR_MasterAudioMux` return shape and direct test callers, and an unhandled bank-to-cameo policy assertion in `tests/test_cast_lock_policy_repin.py`.

## MUST-FIX BEFORE BUILD

1. [Section 5, lines 332-334 (D2: Story Draft Persistence)]
   - Defect: Plan specifies using `comfy_execution.utils.get_executing_context()` in `_otr_story_drafts.py` to identify the prompt execution and node ID for draft persistence. In this repository's standalone testing environment (`.venv`), the ComfyUI core runner (`C:\Users\jeffr\ComfyUI-Installs\ComfyUI\ComfyUI`) is not installed as an importable package and is not present in `sys.path`. Calling `import comfy_execution.utils` will raise `ModuleNotFoundError` during standard pytest invocation (`pytest tests/`), breaking tests importing `_otr_story_drafts.py` or `OTR_LedgerScriptWriter.py`.
   - Concrete Fix: Encapsulate context extraction inside a resilient helper in `nodes/_otr_story_drafts.py`:
     ```python
     def get_prompt_execution_context(prompt_id: str | None = None, node_id: str | None = None) -> dict[str, str]:
         if prompt_id and node_id:
             return {"prompt_id": str(prompt_id), "node_id": str(node_id)}
         try:
             import comfy_execution.utils
             ctx = comfy_execution.utils.get_executing_context()
             if ctx:
                 return {
                     "prompt_id": str(ctx.get("prompt_id", "interactive")),
                     "node_id": str(ctx.get("node_id", "1")),
                 }
         except (ImportError, ModuleNotFoundError):
             pass
         return {"prompt_id": "test_standalone", "node_id": "1"}
     ```
     Ensure `_resolve_inputs` and draft loading/saving methods pass optional overrides or fall back cleanly to `"test_standalone"` when executing outside an active ComfyUI graph run.

2. [Section 7, lines 438-446 and Section 9, lines 654-661 (D4 / Chunk 3 & Chunk 4: Mux Return Signature Migration)]
   - Defect: Chunk 3 (Section 9, line 654) adds optional `script_json=None` to `OTR_MasterAudioMux.mux()` and implements delivery intent enforcement (`verify: delivery intent check`). Chunk 4 (Section 9, lines 659-661) modifies `mux()` to return the ComfyUI UI envelope `{"ui": {"gifs": [...], "files": [...]}, "result": (final_audio, report)}` and updates caller tests. However, multiple active tests in `tests/test_publication_eligibility.py` (lines 582, 621, 679) and `tests/test_video_render_path_cw4.py` (lines 142, 375) invoke `mux()` directly as `out_audio, out_report = mux(...)`. If Chunk 3 or Chunk 4 separates the return shape change from test caller migration, or if any test runs between these changes, pytest will fail with `ValueError: too many values to unpack (expected 2)`.
   - Concrete Fix: Explicitly pin in Chunk 3 that `OTR_MasterAudioMux.mux()` retains the exact 2-tuple return `(final_audio, report)` while adding `script_json=None`. Then, in Chunk 4, atomically bundle:
     a) Updating `OTR_MasterAudioMux.mux()` return to `{"ui": ..., "result": (final_audio, report)}`.
     b) Updating direct call sites in `tests/test_publication_eligibility.py` and `tests/test_video_render_path_cw4.py` to extract `result` (e.g., via a shared test helper `_unpack_mux_result(res)` that handles both 2-tuple and dict shapes during migration).
     c) Updating `OTR_MasterAudioMux.RETURN_TYPES` and `OTR_MasterAudioMux.RETURN_NAMES` declarations if required, or documenting that ComfyUI UI-dict wrapping does not alter `RETURN_TYPES = ("AUDIO", "STRING")`.

3. [Section 4, lines 212-216 and Section 5, line 245 (D1 / D2: Cameo Policy Matrix Lock)]
   - Defect: Section 5 registers `"my_story"` in `data/story_routing/banks.json`. However, `tests/test_cast_lock_policy_repin.py` contains `test_every_shipped_bank_has_a_DECIDED_cameo_policy()` (lines 48-52), which asserts:
     ```python
     for bank_id in shipped_banks:
         assert bank_id in BANK_CAMEO_POLICY, f"Bank {bank_id} missing cameo policy"
     ```
     Registering `my_story` without declaring its policy in `BANK_CAMEO_POLICY` in `tests/test_cast_lock_policy_repin.py` will cause this regression test to fail immediately upon bank registration in Chunk 2. Furthermore, the plan does not specify whether `my_story` permits or forbids automatic cameo injection (e.g., Lemmy cameo in `_source_bank_excludes_lemmy` in `nodes/_otr_story_routing.py:L268`).
   - Concrete Fix: In Chunk 2 (or Chunk 3), explicitly add `"my_story"` to `BANK_CAMEO_POLICY` in `tests/test_cast_lock_policy_repin.py`:
     ```python
     "my_story": CameoPolicy.FORBIDDEN,  # User custom story banks do not inject legacy cast cameos
     ```
     and update `_source_bank_excludes_lemmy()` in `nodes/_otr_story_routing.py` to include `"my_story"`, guaranteeing user-authored stories are not polluted by automated cameo insertions [ASSUMPTION: custom stories should exclude default Lemmy cameos unless explicitly requested by the user in character descriptions].

## SHOULD-FIX

1. [Section 9, lines 618-620 (D0: Relative Markdown Links)]
   - Defect: Links `[Opus cleanup handoff](2026-09-10-cleanup-opus/HANDOFF.md)` and `[GO_FORWARD_PLAN](GO_FORWARD_PLAN.md)` are relative to an assumed directory structure but do not resolve from `kibitz-runs/2026-09-10-my-story-app/r4/input.md`.
   - Concrete Fix: Qualify document links with explicit repo paths: `docs/planning/2026-09-10-cleanup-opus/HANDOFF.md` and `docs/planning/2026-09-10-my-story-app/GO_FORWARD_PLAN.md`.

2. [Section 5, lines 260-264 (D2: Cross-Bank Field Validation Contract)]
   - Defect: The specification states that populating dedicated fields (`story_characters`, `story_plot`, `story_setting`) when `source_bank != "my_story"` "raises ValueError or displays warning". Ambiguity between raising an exception and logging a warning leads to test inconsistencies and undefined UI behavior.
   - Concrete Fix: Lock the exact validation behavior in `nodes/_otr_writer_inputs.py:_resolve_inputs()`: if any of `story_characters`, `story_plot`, or `story_setting` contains non-whitespace text while `source_bank != "my_story"`, raise `ValueError(f"Dedicated story fields are only valid when source_bank='my_story', but source_bank is '{source_bank}'. Clear these fields or switch source_bank to 'my_story'.")`.

3. [Section 5, lines 309-317 (D2: Draft File Persistence Hygiene)]
   - Defect: Writing drafts directly to `otr_state_dir() / "story_drafts" / f"{bank_id}_{prompt_id}.json"` without atomic write semantics risks corrupted JSON if ComfyUI execution is interrupted, aborted by the user, or encounters an Out-Of-Memory (OOM) error during generation.
   - Concrete Fix: Specify an atomic write pattern in `_otr_story_drafts.py`: write to a temporary file (`.tmp`) in the same state directory and rename via `os.replace`. Enforce a maximum file retention/cleanup policy or limit draft file sizes to prevent unbounded disk growth in `episodes/_shared/state/story_drafts/`.

## OPTIONAL / NICE-TO-HAVE

1. [Section 5, lines 285-295 (D2: Draft Schema Versioning)]
   - Include a top-level `"schema_version": 1` field in the draft JSON schema. If the dedicated story field structure evolves (e.g., adding structured beat outlines or tone selectors), reader functions can cleanly validate or migrate draft files.

2. [Section 7, lines 504-507 (D4: Dual Format App Mode Reports)]
   - In `ui.files`, consider outputting both the formatted `.txt` summary and the raw `.json` episode manifest. The ComfyUI frontend file viewer supports both, enabling power users to download the machine-readable manifest directly from App Mode.

## CUT THESE

1. [Section 6, lines 405-406 (D3: Graph-View Dynamic Widget Hiding Extensions)]
   - Re-confirm that custom JavaScript for dynamic widget hiding or conditional form wizard logic in the default ComfyUI graph view is strictly out of scope.
   - Rationale: ComfyUI's native LiteGraph core does not natively support reactive widget hiding without bespoke extension scripts. Implementing this violates the project's zero-frontend-dependency architectural boundary. In standard graph view, empty optional text widgets are completely harmless; App Mode native linear view handles presentation cleanly via the verified `Dy = new Set(['animated', 'text'])` and `linearData.inputs` rendering paths.

## VERIFY-AT-BUILD

1. **App Mode MP4 Video Playback (`ui.gifs` envelope):**
   - Verify in ComfyUI frontend v1.49.6 that `ui.gifs = [{"filename": ..., "subfolder": ..., "type": "output", "format": "video/mp4"}]` is picked up by `isResultItem()` and `isVideo` evaluates to true in `GraphView-CNdynQTM.js`, successfully rendering the HTML5 `<video>` player in App Mode.

2. **App Mode Text Report Preview (`ui.files` envelope):**
   - Verify in ComfyUI frontend v1.49.6 that `ui.files = [{"filename": ..., "subfolder": ..., "type": "output", "format": "text/plain"}]` is parsed by `isResultItem()` and `isText` evaluates to true, rendering the inline text summary card in App Mode.

3. **Workflow Link and Input Index Integrity:**
   - Verify that running `python scripts/build_variants.py --check` and `pytest tests/test_workflow_link_target_indexes.py` pass cleanly after:
     a) Appending 3 optional string widgets (`story_characters`, `story_plot`, `story_setting`) to Node 1 (`OTR_LedgerScriptWriter`), expanding inputs to 37 (indices 0..36) and `widgets_values` to 36 (indices 0..35) without shifting link 279 at input slot 32.
     b) Appending input slot 10 (`script_json`, `forceInput: true`) to Node 85 (`OTR_MasterAudioMux`) and linking Node 1 output slot 1 via link 291.

4. **Prompt Cache Invalidation (`OTR_MasterAudioMux.IS_CHANGED`):**
   - Verify that `OTR_MasterAudioMux.IS_CHANGED()` invalidates cache appropriately when the generated output video file is removed from disk or when `script_json` content changes.

5. **Test Isolation from ComfyUI Core:**
   - Verify that running `pytest tests/` in a clean Python environment without ComfyUI core on `sys.path` executes without `ModuleNotFoundError` on `_otr_story_drafts.py`.
