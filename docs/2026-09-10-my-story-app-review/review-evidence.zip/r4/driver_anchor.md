VERDICT: yes as a hardened scope, not an implementation-ready independent bank.

Written before R4 fanout. Input is exact R3 final. Codex is grounded driver
and sole judge; external reviewers Gemini and Cursor are independent seats.

CONVERGENCE TARGET
Scope optional fields, retained act/character counts, LLM completion to ledger,
durable input drafts and REQUIRED published My Story success in normal graph
or optional App view. Include README/linked guide currentization. No coding.

LATEST OPERATOR PRIORITY / COMBINED HANDOFF
Read docs/GO_FORWARD_PLAN.md and docs/2026-09-10-cleanup-opus/HANDOFF.md plus
PLAN.md. These plans together are priority #1: Opus P1(C4+C1), then separately
qualified P2(C2) and P3(C3), then My Story D0 docs against cleaned-up HEAD and
D1 independent design, then backend/graph/canonical required delivery, then
optional App presentation and qualification. One coder owns shared files at
a time. The older Ghost proof resumes afterward. Cleanup has its OWN finished
R1-R4 campaign; do not redo it or imply this campaign's earlier rounds covered
it. Check only the combined ordering, handoff, scope boundaries and remaining
My Story contradictions. Two read-only helpers agreed with this sequence.
Speaker placement is optional later design, not cleanup P1 or a blocker:
balanced gentle positions by stable speaker identity, narrator centered,
supported cast sizes, explicit channel/timing/cache/replay/listening proof.
Runtime cleanup is pending; its baseline has 54 existing failures, not a clean
suite. Preparation HEAD is a3551ff5; future coder revalidates their actual HEAD.

GROUNDING
Canonical schema changes now land with new widgets/functional terminal wire,
before bank runnable. gate_in remains input32/link279; replay is widget32.
Drafts use existing persistent _shared/state, one coordinator and per-queued-writer
identity. File-backed source authority is resolved/pinned outside pure admission.
New dedicated fields on wrong bank fail, old premise-plus-roll stays unchanged.

Terminal gets existing writer script_json through one new optional input.
Typed requirement + stable delivery token survive disk-ledger loss and normal
episode rename; replay refreshes token while preserving frozen requirements.
Freeze alone grants publication; required delivery refusal/missing output fails.
Actual OBS AAC is player source; archival wire meaning is preserved. App view
is optional; native save/history/replay and explicit root limitations are covered.

MUST RESOLVE ONLY IF NEW
Any remaining scope-level wiring contradiction, lost field/draft or false My
Story success path. D1's explicit schemas/DAG/cast/cameo/ownership obligations
are intentionally gated design work, not a claim they are implemented. Do not
equate scope convergence with a bank preflight PASS or live qualification.
No new UI framework, copied workflow, model routing, content filters or word gates.
